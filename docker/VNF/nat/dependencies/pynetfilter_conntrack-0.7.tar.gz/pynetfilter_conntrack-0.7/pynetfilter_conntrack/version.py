PACKAGE = "pynetfilter_conntrack"
VERSION = '0.7'
WEBSITE = "https://github.com/regit/pynetfilter_conntrack/"
LICENSE = "GNU GPL"

